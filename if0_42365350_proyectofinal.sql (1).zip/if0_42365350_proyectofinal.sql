-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: sql213.infinityfree.com
-- Tiempo de generación: 25-10-2026 a las 10:46:27
-- Versión del servidor: 11.4.13-MariaDB
-- Versión de PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_42365350_proyectofinal`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividades`
--

CREATE TABLE `actividades` (
  `id` int(11) NOT NULL,
  `nombre_actividad` varchar(100) NOT NULL,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `actividades`
--

INSERT INTO `actividades` (`id`, `nombre_actividad`, `fecha_creacion`) VALUES
(1, 'Banda', '2026-10-14 14:52:41'),
(2, 'Fútbol', '2026-10-14 14:52:41'),
(3, 'Básquetbol', '2026-10-14 14:52:41'),
(4, 'Voleyball', '2026-10-14 14:52:41'),
(5, 'Huerto', '2026-10-14 14:52:41'),
(6, 'Danza', '2026-10-14 14:52:41'),
(7, 'Limpieza', '2026-10-14 14:52:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bitacora_servicio_social`
--

CREATE TABLE `bitacora_servicio_social` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL,
  `seccion` varchar(50) NOT NULL,
  `nombre_proyecto` varchar(150) NOT NULL,
  `fecha` date NOT NULL,
  `encargado` varchar(100) NOT NULL,
  `firma_encargado` varchar(150) DEFAULT NULL,
  `actividades` text NOT NULL,
  `horas` decimal(4,2) NOT NULL,
  `hora_entrada` time NOT NULL,
  `hora_salida` time NOT NULL,
  `firma_alumno` varchar(150) DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `bitacora_servicio_social`
--

INSERT INTO `bitacora_servicio_social` (`id`, `nombre_estudiante`, `seccion`, `nombre_proyecto`, `fecha`, `encargado`, `firma_encargado`, `actividades`, `horas`, `hora_entrada`, `hora_salida`, `firma_alumno`, `fecha_creacion`) VALUES
(1, 'Andrea Beatriz Galdámez', '1-1', 'Apoyo administrativo escolar', '0000-00-00', ' Mirma Xiomara Jiménez Lazo', 'yo', 'Fútbol', '2.00', '09:00:00', '11:00:00', 'yo', '2026-10-15 14:58:04'),
(2, 'Andrea Beatriz Galdámez', '1-1', 'Apoyo administrativo escolar', '0000-00-00', ' Mirma Xiomara Jiménez Lazo', 'yo', 'Fútbol', '1.00', '09:00:00', '10:00:00', 'yo', '2026-10-15 15:00:29'),
(3, 'Cristian Alexander Granados', '1-2', 'Apoyo administrativo escolar', '0000-00-00', ' Mirma Xiomara Jiménez Lazo', 'yo', 'Huerto', '3.00', '10:04:00', '13:04:00', '', '2026-10-15 15:04:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encargados`
--

CREATE TABLE `encargados` (
  `id` int(11) NOT NULL,
  `nombre_encargado` varchar(150) NOT NULL,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `encargados`
--

INSERT INTO `encargados` (`id`, `nombre_encargado`, `fecha_creacion`) VALUES
(1, ' Mirma Xiomara Jiménez Lazo', '2026-10-08 14:47:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_1`
--

CREATE TABLE `estudiantes_1_1` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL,
  `seccion` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_1`
--

INSERT INTO `estudiantes_1_1` (`id`, `nombre_estudiante`, `seccion`) VALUES
(1, 'Alejandro José Martínez', '1-1'),
(2, 'Sofía Valentina Hernández', '1-1'),
(3, 'Carlos Eduardo Ramírez', '1-1'),
(4, 'María Fernanda Flores', '1-1'),
(5, 'Diego Armando Rivas', '1-1'),
(6, 'Gabriela Nicole Morales', '1-1'),
(7, 'José David Castro', '1-1'),
(8, 'Valeria Abigail Benítez', '1-1'),
(9, 'Kevin Alexander Portillo', '1-1'),
(10, 'Andrea Beatriz Galdámez', '1-1'),
(11, 'Francisco Javier Meléndez', '1-1'),
(12, 'Daniela Alexandra Orellana', '1-1'),
(13, 'Bryan Stiven Amaya', '1-1'),
(14, 'Fatima Guadalupe Ventura', '1-1'),
(15, 'Oscar Mauricio Pineda', '1-1'),
(16, 'Paola Michelle Escobar', '1-1'),
(17, 'Jonathan Alexander Meza', '1-1'),
(18, 'Diana Carolina Turcios', '1-1'),
(19, 'Christian Eduardo Vásquez', '1-1'),
(20, 'Katerin Noemí Alfaro', '1-1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_2`
--

CREATE TABLE `estudiantes_1_2` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_2`
--

INSERT INTO `estudiantes_1_2` (`id`, `nombre_estudiante`) VALUES
(1, 'Marcos Daniel Rivas'),
(2, 'Lucía Gabriela Campos'),
(3, 'Héctor Manuel Sermeño'),
(4, 'Brenda Lizeth Molina'),
(5, 'Steven Josué Zepeda'),
(6, 'Karla Vanessa Palacios'),
(7, 'Nelson Enrique Argueta'),
(8, 'Wendy Esmeralda Cruz'),
(9, 'Mauricio Ernesto Flores'),
(10, 'Claudia Marcela Guevara'),
(11, 'René Alonso Quintanilla'),
(12, 'Fabiola Alexandra Lemus'),
(13, 'Eduardo Antonio Larios'),
(14, 'Rebeca Noemí Sibrián'),
(15, 'Cristian Alexander Granados'),
(16, 'Mónica Beatriz Salguero'),
(17, 'Adán Alberto Coto'),
(18, 'Kenia Raquel Portillo'),
(19, 'Ernesto Alonso Duarte'),
(20, 'Jocelyn Abigail Menjívar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_3`
--

CREATE TABLE `estudiantes_1_3` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_3`
--

INSERT INTO `estudiantes_1_3` (`id`, `nombre_estudiante`) VALUES
(1, 'Alexander Josué Bonilla'),
(2, 'Tatiana Marisol Zelaya'),
(3, 'William Ernesto Orellana'),
(4, 'Iris Carolina Amaya'),
(5, 'Óscar Antonio Pineda'),
(6, 'Gabriela Estefanía Escobar'),
(7, 'Francisco Javier Navas'),
(8, 'Alejandra Beatriz Rivas'),
(9, 'José Mario Hernández'),
(10, 'Karen Vanessa Medina'),
(11, 'Denis Alexander Landaverde'),
(12, 'María de los Ángeles Sosa'),
(13, 'Carlos Roberto Galdámez'),
(14, 'Sonia Elizabeth Marroquín'),
(15, 'Walter Enrique Perdomo'),
(16, 'Jessica Yamileth Guardado'),
(17, 'Miguel Ángel Crespín'),
(18, 'Fatima Michelle Coreas'),
(19, 'Ever Adalberto Chicas'),
(20, 'Silvia Elena Palacios');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_4`
--

CREATE TABLE `estudiantes_1_4` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_4`
--

INSERT INTO `estudiantes_1_4` (`id`, `nombre_estudiante`) VALUES
(1, 'Gabriel Enrique Villatoro'),
(2, 'Saraí Abigail Meléndez'),
(3, 'Jonathan Ezequiel Monge'),
(4, 'Esmeralda del Carmen Cruz'),
(5, 'Roberto Carlos Aguilar'),
(6, 'Johana Lizeth Alfaro'),
(7, 'Víctor Manuel Osorio'),
(8, 'Paola Vanessa Benítez'),
(9, 'Saúl Antonio Guevara'),
(10, 'Daniela Nicole Cárdenas'),
(11, 'Bryan Alexander Turcios'),
(12, 'Katherine Yamileth Ramos'),
(13, 'Josué David Molina'),
(14, 'Ana Ruth Portillo'),
(15, 'Kevin Estuardo Zaldaña'),
(16, 'Melissa Guadalupe Castro'),
(17, 'Edgar Mauricio Fuentes'),
(18, 'Roxana Beatriz Santos'),
(19, 'Nelson Adalid Blanco'),
(20, 'Jennifer Alexandra Matías');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_5`
--

CREATE TABLE `estudiantes_1_5` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_5`
--

INSERT INTO `estudiantes_1_5` (`id`, `nombre_estudiante`) VALUES
(1, 'Mauricio Alejandro Ayala'),
(2, 'Valeria Sofía Murillo'),
(3, 'Ricardo Enrique Valladares'),
(4, 'Brenda Beatriz Chinchilla'),
(5, 'Fernando José Alvarenga'),
(6, 'Diana Marcela Palomo'),
(7, 'Julio César Grijalva'),
(8, 'Fatima Abigail Galán'),
(9, 'Oscar David Interiano'),
(10, 'Claudia Patricia Guardado'),
(11, 'Cristian Edgardo Granados'),
(12, 'Karen Elizabeth Jovel'),
(13, 'Manuel de Jesús Rivas'),
(14, 'Stephanie Michelle Lemus'),
(15, 'Adán Estuardo Sermeño'),
(16, 'Tatiana Raquel Escobar'),
(17, 'Francisco Antonio Merlos'),
(18, 'Rebeca Alexandra Campos'),
(19, 'Gerardo Antonio Morán'),
(20, 'Josselyn Nicole Sibrián');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_6`
--

CREATE TABLE `estudiantes_1_6` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_6`
--

INSERT INTO `estudiantes_1_6` (`id`, `nombre_estudiante`) VALUES
(1, 'Daniel Alejandro Pineda'),
(2, 'Adriana Gabriela Molina'),
(3, 'Carlos Humberto Orellana'),
(4, 'Lucía del Carmen Zepeda'),
(5, 'Jorge Mario Portillo'),
(6, 'Karla Estefanía Amaya'),
(7, 'William Alexander Galdámez'),
(8, 'Wendy Alejandra Cruz'),
(9, 'José Enrique Menjívar'),
(10, 'Iris Marisol Marroquín'),
(11, 'Steven Adalberto Flores'),
(12, 'María Fernanda Larios'),
(13, 'Kevin Ernesto Meléndez'),
(14, 'Sonia Noemí Benítez'),
(15, 'Walter Vladimir Coto'),
(16, 'Jessica Beatriz Salguero'),
(17, 'Miguel Antonio Duarte'),
(18, 'Fatima Alexandra Turcios'),
(19, 'Ever Stiven Alfaro'),
(20, 'Silvia Guadalupe Guardado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_7`
--

CREATE TABLE `estudiantes_1_7` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_7`
--

INSERT INTO `estudiantes_1_7` (`id`, `nombre_estudiante`) VALUES
(1, 'Alejandro José Martínez'),
(2, 'Sofía Valentina Hernández'),
(3, 'Carlos Eduardo Ramírez'),
(4, 'María Fernanda Flores'),
(5, 'Diego Armando Rivas'),
(6, 'Gabriela Nicole Morales'),
(7, 'José David Castro'),
(8, 'Valeria Abigail Benítez'),
(9, 'Kevin Alexander Portillo'),
(10, 'Andrea Beatriz Galdámez'),
(11, 'Francisco Javier Meléndez'),
(12, 'Daniela Alexandra Orellana'),
(13, 'Bryan Stiven Amaya'),
(14, 'Fatima Guadalupe Ventura'),
(15, 'Oscar Mauricio Pineda'),
(16, 'Paola Michelle Escobar'),
(17, 'Jonathan Alexander Meza'),
(18, 'Diana Carolina Turcios'),
(19, 'Christian Eduardo Vásquez'),
(20, 'Katerin Noemí Alfaro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_8`
--

CREATE TABLE `estudiantes_1_8` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_8`
--

INSERT INTO `estudiantes_1_8` (`id`, `nombre_estudiante`) VALUES
(1, 'Marcos Daniel Rivas'),
(2, 'Lucía Gabriela Campos'),
(3, 'Héctor Manuel Sermeño'),
(4, 'Brenda Lizeth Molina'),
(5, 'Steven Josué Zepeda'),
(6, 'Karla Vanessa Palacios'),
(7, 'Nelson Enrique Argueta'),
(8, 'Wendy Esmeralda Cruz'),
(9, 'Mauricio Ernesto Flores'),
(10, 'Claudia Marcela Guevara'),
(11, 'René Alonso Quintanilla'),
(12, 'Fabiola Alexandra Lemus'),
(13, 'Eduardo Antonio Larios'),
(14, 'Rebeca Noemí Sibrián'),
(15, 'Cristian Alexander Granados'),
(16, 'Mónica Beatriz Salguero'),
(17, 'Adán Alberto Coto'),
(18, 'Kenia Raquel Portillo'),
(19, 'Ernesto Alonso Duarte'),
(20, 'Jocelyn Abigail Menjívar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_9`
--

CREATE TABLE `estudiantes_1_9` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_9`
--

INSERT INTO `estudiantes_1_9` (`id`, `nombre_estudiante`) VALUES
(1, 'Alexander Josué Bonilla'),
(2, 'Tatiana Marisol Zelaya'),
(3, 'William Ernesto Orellana'),
(4, 'Iris Carolina Amaya'),
(5, 'Óscar Antonio Pineda'),
(6, 'Gabriela Estefanía Escobar'),
(7, 'Francisco Javier Navas'),
(8, 'Alejandra Beatriz Rivas'),
(9, 'José Mario Hernández'),
(10, 'Karen Vanessa Medina'),
(11, 'Denis Alexander Landaverde'),
(12, 'María de los Ángeles Sosa'),
(13, 'Carlos Roberto Galdámez'),
(14, 'Sonia Elizabeth Marroquín'),
(15, 'Walter Enrique Perdomo'),
(16, 'Jessica Yamileth Guardado'),
(17, 'Miguel Ángel Crespín'),
(18, 'Fatima Michelle Coreas'),
(19, 'Ever Adalberto Chicas'),
(20, 'Silvia Elena Palacios');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_10`
--

CREATE TABLE `estudiantes_1_10` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_10`
--

INSERT INTO `estudiantes_1_10` (`id`, `nombre_estudiante`) VALUES
(1, 'Gabriel Enrique Villatoro'),
(2, 'Saraí Abigail Meléndez'),
(3, 'Jonathan Ezequiel Monge'),
(4, 'Esmeralda del Carmen Cruz'),
(5, 'Roberto Carlos Aguilar'),
(6, 'Johana Lizeth Alfaro'),
(7, 'Víctor Manuel Osorio'),
(8, 'Paola Vanessa Benítez'),
(9, 'Saúl Antonio Guevara'),
(10, 'Daniela Nicole Cárdenas'),
(11, 'Bryan Alexander Turcios'),
(12, 'Katherine Yamileth Ramos'),
(13, 'Josué David Molina'),
(14, 'Ana Ruth Portillo'),
(15, 'Kevin Estuardo Zaldaña'),
(16, 'Melissa Guadalupe Castro'),
(17, 'Edgar Mauricio Fuentes'),
(18, 'Roxana Beatriz Santos'),
(19, 'Nelson Adalid Blanco'),
(20, 'Jennifer Alexandra Matías');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_1_11`
--

CREATE TABLE `estudiantes_1_11` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_1_11`
--

INSERT INTO `estudiantes_1_11` (`id`, `nombre_estudiante`) VALUES
(1, 'Mauricio Alejandro Ayala'),
(2, 'Valeria Sofía Murillo'),
(3, 'Ricardo Enrique Valladares'),
(4, 'Brenda Beatriz Chinchilla'),
(5, 'Fernando José Alvarenga'),
(6, 'Diana Marcela Palomo'),
(7, 'Julio César Grijalva'),
(8, 'Fatima Abigail Galán'),
(9, 'Oscar David Interiano'),
(10, 'Claudia Patricia Guardado'),
(11, 'Cristian Edgardo Granados'),
(12, 'Karen Elizabeth Jovel'),
(13, 'Manuel de Jesús Rivas'),
(14, 'Stephanie Michelle Lemus'),
(15, 'Adán Estuardo Sermeño'),
(16, 'Tatiana Raquel Escobar'),
(17, 'Francisco Antonio Merlos'),
(18, 'Rebeca Alexandra Campos'),
(19, 'Gerardo Antonio Morán'),
(20, 'Josselyn Nicole Sibrián');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_1`
--

CREATE TABLE `estudiantes_2_1` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_1`
--

INSERT INTO `estudiantes_2_1` (`id`, `nombre_estudiante`) VALUES
(1, 'Daniel Alejandro Pineda'),
(2, 'Adriana Gabriela Molina'),
(3, 'Carlos Humberto Orellana'),
(4, 'Lucía del Carmen Zepeda'),
(5, 'Jorge Mario Portillo'),
(6, 'Karla Estefanía Amaya'),
(7, 'William Alexander Galdámez'),
(8, 'Wendy Alejandra Cruz'),
(9, 'José Enrique Menjívar'),
(10, 'Iris Marisol Marroquín'),
(11, 'Steven Adalberto Flores'),
(12, 'María Fernanda Larios'),
(13, 'Kevin Ernesto Meléndez'),
(14, 'Sonia Noemí Benítez'),
(15, 'Walter Vladimir Coto'),
(16, 'Jessica Beatriz Salguero'),
(17, 'Miguel Antonio Duarte'),
(18, 'Fatima Alexandra Turcios'),
(19, 'Ever Stiven Alfaro'),
(20, 'Silvia Guadalupe Guardado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_2`
--

CREATE TABLE `estudiantes_2_2` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_2`
--

INSERT INTO `estudiantes_2_2` (`id`, `nombre_estudiante`) VALUES
(1, 'Alejandro José Martínez'),
(2, 'Sofía Valentina Hernández'),
(3, 'Carlos Eduardo Ramírez'),
(4, 'María Fernanda Flores'),
(5, 'Diego Armando Rivas'),
(6, 'Gabriela Nicole Morales'),
(7, 'José David Castro'),
(8, 'Valeria Abigail Benítez'),
(9, 'Kevin Alexander Portillo'),
(10, 'Andrea Beatriz Galdámez'),
(11, 'Francisco Javier Meléndez'),
(12, 'Daniela Alexandra Orellana'),
(13, 'Bryan Stiven Amaya'),
(14, 'Fatima Guadalupe Ventura'),
(15, 'Oscar Mauricio Pineda'),
(16, 'Paola Michelle Escobar'),
(17, 'Jonathan Alexander Meza'),
(18, 'Diana Carolina Turcios'),
(19, 'Christian Eduardo Vásquez'),
(20, 'Katerin Noemí Alfaro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_3`
--

CREATE TABLE `estudiantes_2_3` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_3`
--

INSERT INTO `estudiantes_2_3` (`id`, `nombre_estudiante`) VALUES
(1, 'Marcos Daniel Rivas'),
(2, 'Lucía Gabriela Campos'),
(3, 'Héctor Manuel Sermeño'),
(4, 'Brenda Lizeth Molina'),
(5, 'Steven Josué Zepeda'),
(6, 'Karla Vanessa Palacios'),
(7, 'Nelson Enrique Argueta'),
(8, 'Wendy Esmeralda Cruz'),
(9, 'Mauricio Ernesto Flores'),
(10, 'Claudia Marcela Guevara'),
(11, 'René Alonso Quintanilla'),
(12, 'Fabiola Alexandra Lemus'),
(13, 'Eduardo Antonio Larios'),
(14, 'Rebeca Noemí Sibrián'),
(15, 'Cristian Alexander Granados'),
(16, 'Mónica Beatriz Salguero'),
(17, 'Adán Alberto Coto'),
(18, 'Kenia Raquel Portillo'),
(19, 'Ernesto Alonso Duarte'),
(20, 'Jocelyn Abigail Menjívar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_4`
--

CREATE TABLE `estudiantes_2_4` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_4`
--

INSERT INTO `estudiantes_2_4` (`id`, `nombre_estudiante`) VALUES
(1, 'Alexander Josué Bonilla'),
(2, 'Tatiana Marisol Zelaya'),
(3, 'William Ernesto Orellana'),
(4, 'Iris Carolina Amaya'),
(5, 'Óscar Antonio Pineda'),
(6, 'Gabriela Estefanía Escobar'),
(7, 'Francisco Javier Navas'),
(8, 'Alejandra Beatriz Rivas'),
(9, 'José Mario Hernández'),
(10, 'Karen Vanessa Medina'),
(11, 'Denis Alexander Landaverde'),
(12, 'María de los Ángeles Sosa'),
(13, 'Carlos Roberto Galdámez'),
(14, 'Sonia Elizabeth Marroquín'),
(15, 'Walter Enrique Perdomo'),
(16, 'Jessica Yamileth Guardado'),
(17, 'Miguel Ángel Crespín'),
(18, 'Fatima Michelle Coreas'),
(19, 'Ever Adalberto Chicas'),
(20, 'Silvia Elena Palacios');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_5`
--

CREATE TABLE `estudiantes_2_5` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_5`
--

INSERT INTO `estudiantes_2_5` (`id`, `nombre_estudiante`) VALUES
(1, 'Gabriel Enrique Villatoro'),
(2, 'Saraí Abigail Meléndez'),
(3, 'Jonathan Ezequiel Monge'),
(4, 'Esmeralda del Carmen Cruz'),
(5, 'Roberto Carlos Aguilar'),
(6, 'Johana Lizeth Alfaro'),
(7, 'Víctor Manuel Osorio'),
(8, 'Paola Vanessa Benítez'),
(9, 'Saúl Antonio Guevara'),
(10, 'Daniela Nicole Cárdenas'),
(11, 'Bryan Alexander Turcios'),
(12, 'Katherine Yamileth Ramos'),
(13, 'Josué David Molina'),
(14, 'Ana Ruth Portillo'),
(15, 'Kevin Estuardo Zaldaña'),
(16, 'Melissa Guadalupe Castro'),
(17, 'Edgar Mauricio Fuentes'),
(18, 'Roxana Beatriz Santos'),
(19, 'Nelson Adalid Blanco'),
(20, 'Jennifer Alexandra Matías');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_6`
--

CREATE TABLE `estudiantes_2_6` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_6`
--

INSERT INTO `estudiantes_2_6` (`id`, `nombre_estudiante`) VALUES
(1, 'Mauricio Alejandro Ayala'),
(2, 'Valeria Sofía Murillo'),
(3, 'Ricardo Enrique Valladares'),
(4, 'Brenda Beatriz Chinchilla'),
(5, 'Fernando José Alvarenga'),
(6, 'Diana Marcela Palomo'),
(7, 'Julio César Grijalva'),
(8, 'Fatima Abigail Galán'),
(9, 'Oscar David Interiano'),
(10, 'Claudia Patricia Guardado'),
(11, 'Cristian Edgardo Granados'),
(12, 'Karen Elizabeth Jovel'),
(13, 'Manuel de Jesús Rivas'),
(14, 'Stephanie Michelle Lemus'),
(15, 'Adán Estuardo Sermeño'),
(16, 'Tatiana Raquel Escobar'),
(17, 'Francisco Antonio Merlos'),
(18, 'Rebeca Alexandra Campos'),
(19, 'Gerardo Antonio Morán'),
(20, 'Josselyn Nicole Sibrián');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_7`
--

CREATE TABLE `estudiantes_2_7` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_7`
--

INSERT INTO `estudiantes_2_7` (`id`, `nombre_estudiante`) VALUES
(1, 'Daniel Alejandro Pineda'),
(2, 'Adriana Gabriela Molina'),
(3, 'Carlos Humberto Orellana'),
(4, 'Lucía del Carmen Zepeda'),
(5, 'Jorge Mario Portillo'),
(6, 'Karla Estefanía Amaya'),
(7, 'William Alexander Galdámez'),
(8, 'Wendy Alejandra Cruz'),
(9, 'José Enrique Menjívar'),
(10, 'Iris Marisol Marroquín'),
(11, 'Steven Adalberto Flores'),
(12, 'María Fernanda Larios'),
(13, 'Kevin Ernesto Meléndez'),
(14, 'Sonia Noemí Benítez'),
(15, 'Walter Vladimir Coto'),
(16, 'Jessica Beatriz Salguero'),
(17, 'Miguel Antonio Duarte'),
(18, 'Fatima Alexandra Turcios'),
(19, 'Ever Stiven Alfaro'),
(20, 'Silvia Guadalupe Guardado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_8`
--

CREATE TABLE `estudiantes_2_8` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_8`
--

INSERT INTO `estudiantes_2_8` (`id`, `nombre_estudiante`) VALUES
(1, 'Alejandro José Martínez'),
(2, 'Sofía Valentina Hernández'),
(3, 'Carlos Eduardo Ramírez'),
(4, 'María Fernanda Flores'),
(5, 'Diego Armando Rivas'),
(6, 'Gabriela Nicole Morales'),
(7, 'José David Castro'),
(8, 'Valeria Abigail Benítez'),
(9, 'Kevin Alexander Portillo'),
(10, 'Andrea Beatriz Galdámez'),
(11, 'Francisco Javier Meléndez'),
(12, 'Daniela Alexandra Orellana'),
(13, 'Bryan Stiven Amaya'),
(14, 'Fatima Guadalupe Ventura'),
(15, 'Oscar Mauricio Pineda'),
(16, 'Paola Michelle Escobar'),
(17, 'Jonathan Alexander Meza'),
(18, 'Diana Carolina Turcios'),
(19, 'Christian Eduardo Vásquez'),
(20, 'Katerin Noemí Alfaro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes_2_9`
--

CREATE TABLE `estudiantes_2_9` (
  `id` int(11) NOT NULL,
  `nombre_estudiante` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estudiantes_2_9`
--

INSERT INTO `estudiantes_2_9` (`id`, `nombre_estudiante`) VALUES
(1, 'Marcos Daniel Rivas'),
(2, 'Lucía Gabriela Campos'),
(3, 'Héctor Manuel Sermeño'),
(4, 'Brenda Lizeth Molina'),
(5, 'Steven Josué Zepeda'),
(6, 'Karla Vanessa Palacios'),
(7, 'Nelson Enrique Argueta'),
(8, 'Wendy Esmeralda Cruz'),
(9, 'Mauricio Ernesto Flores'),
(10, 'Claudia Marcela Guevara'),
(11, 'René Alonso Quintanilla'),
(12, 'Fabiola Alexandra Lemus'),
(13, 'Eduardo Antonio Larios'),
(14, 'Rebeca Noemí Sibrián'),
(15, 'Cristian Alexander Granados'),
(16, 'Mónica Beatriz Salguero'),
(17, 'Adán Alberto Coto'),
(18, 'Kenia Raquel Portillo'),
(19, 'Ernesto Alonso Duarte'),
(20, 'Jocelyn Abigail Menjívar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grados`
--

CREATE TABLE `grados` (
  `id` int(11) NOT NULL,
  `nombre_grado` varchar(50) NOT NULL,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `grados`
--

INSERT INTO `grados` (`id`, `nombre_grado`, `fecha_creacion`) VALUES
(1, '2-1', '2026-10-08 14:46:06'),
(2, '2-2', '2026-10-08 14:46:06'),
(3, '2-3', '2026-10-08 14:46:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `password`, `rol`) VALUES
(1, 'estudiante', 'e4e4564027d73a4325024d948d167e93', 'lector'),
(2, 'profesor', '793741d54b00253006453742ad4ed534', 'administrador');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `actividades`
--
ALTER TABLE `actividades`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `bitacora_servicio_social`
--
ALTER TABLE `bitacora_servicio_social`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `encargados`
--
ALTER TABLE `encargados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_1`
--
ALTER TABLE `estudiantes_1_1`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_2`
--
ALTER TABLE `estudiantes_1_2`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_3`
--
ALTER TABLE `estudiantes_1_3`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_4`
--
ALTER TABLE `estudiantes_1_4`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_5`
--
ALTER TABLE `estudiantes_1_5`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_6`
--
ALTER TABLE `estudiantes_1_6`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_7`
--
ALTER TABLE `estudiantes_1_7`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_8`
--
ALTER TABLE `estudiantes_1_8`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_9`
--
ALTER TABLE `estudiantes_1_9`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_10`
--
ALTER TABLE `estudiantes_1_10`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_1_11`
--
ALTER TABLE `estudiantes_1_11`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_1`
--
ALTER TABLE `estudiantes_2_1`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_2`
--
ALTER TABLE `estudiantes_2_2`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_3`
--
ALTER TABLE `estudiantes_2_3`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_4`
--
ALTER TABLE `estudiantes_2_4`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_5`
--
ALTER TABLE `estudiantes_2_5`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_6`
--
ALTER TABLE `estudiantes_2_6`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_7`
--
ALTER TABLE `estudiantes_2_7`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_8`
--
ALTER TABLE `estudiantes_2_8`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estudiantes_2_9`
--
ALTER TABLE `estudiantes_2_9`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `grados`
--
ALTER TABLE `grados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `actividades`
--
ALTER TABLE `actividades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `bitacora_servicio_social`
--
ALTER TABLE `bitacora_servicio_social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `encargados`
--
ALTER TABLE `encargados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_1`
--
ALTER TABLE `estudiantes_1_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_2`
--
ALTER TABLE `estudiantes_1_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_3`
--
ALTER TABLE `estudiantes_1_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_4`
--
ALTER TABLE `estudiantes_1_4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_5`
--
ALTER TABLE `estudiantes_1_5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_6`
--
ALTER TABLE `estudiantes_1_6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_7`
--
ALTER TABLE `estudiantes_1_7`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_8`
--
ALTER TABLE `estudiantes_1_8`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_9`
--
ALTER TABLE `estudiantes_1_9`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_10`
--
ALTER TABLE `estudiantes_1_10`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_1_11`
--
ALTER TABLE `estudiantes_1_11`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_1`
--
ALTER TABLE `estudiantes_2_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_2`
--
ALTER TABLE `estudiantes_2_2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_3`
--
ALTER TABLE `estudiantes_2_3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_4`
--
ALTER TABLE `estudiantes_2_4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_5`
--
ALTER TABLE `estudiantes_2_5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_6`
--
ALTER TABLE `estudiantes_2_6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_7`
--
ALTER TABLE `estudiantes_2_7`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_8`
--
ALTER TABLE `estudiantes_2_8`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `estudiantes_2_9`
--
ALTER TABLE `estudiantes_2_9`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `grados`
--
ALTER TABLE `grados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
